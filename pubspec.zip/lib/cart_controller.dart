import 'package:flutter/material.dart';

class CartController {
  CartController._();
  static final CartController instance = CartController._();

  final List<Map<String, dynamic>> items = [];

  double get total => items.fold(0, (sum, item) {
    final priceStr = (item['price'] as String)
        .replaceAll('R\$ ', '')
        .replaceAll(',', '.');
    return sum + double.parse(priceStr) * (item['qty'] as int);
  });

  int get totalItems =>
      items.fold(0, (sum, item) => sum + (item['qty'] as int));

  void addItem(Map<String, dynamic> product) {
    final index = items.indexWhere((i) => i['name'] == product['name']);
    if (index >= 0) {
      items[index]['qty']++;
    } else {
      items.add({...product, 'qty': 1});
    }
  }

  void increment(int index) {
    items[index]['qty']++;
  }

  void decrement(int index) {
    if (items[index]['qty'] > 1) {
      items[index]['qty']--;
    } else {
      items.removeAt(index);
    }
  }

  void clear() {
    items.clear();
  }

  bool contains(String name) {
    return items.any((i) => i['name'] == name);
  }

  int qtyOf(String name) {
    final index = items.indexWhere((i) => i['name'] == name);
    return index >= 0 ? items[index]['qty'] as int : 0;
  }
}
