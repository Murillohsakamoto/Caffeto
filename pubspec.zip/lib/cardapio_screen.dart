import 'package:flutter/material.dart';
import 'cart_controller.dart';

class CardapioScreen extends StatefulWidget {
  final VoidCallback? onCartChanged;
  const CardapioScreen({super.key, this.onCartChanged});

  @override
  State<CardapioScreen> createState() => _CardapioScreenState();
}

class _CardapioScreenState extends State<CardapioScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String? _selectedCategory;

  final List<Map<String, dynamic>> categoryList = const [
    {'icon': Icons.coffee, 'label': 'Cafés Quentes'},
    {'icon': Icons.local_drink, 'label': 'Cafés Gelados'},
    {'icon': Icons.cake, 'label': 'Combos'},
  ];

  final List<Map<String, dynamic>> allItems = const [
    {
      'name': 'Cappuccino Clássico',
      'price': 'R\$ 12,90',
      'icon': Icons.coffee,
      'category': 'Cafés Quentes',
    },
    {
      'name': 'Latte de Baunilha',
      'price': 'R\$ 14,90',
      'icon': Icons.local_cafe,
      'category': 'Cafés Quentes',
    },
    {
      'name': 'Espresso Duplo',
      'price': 'R\$ 9,90',
      'icon': Icons.coffee_maker,
      'category': 'Cafés Quentes',
    },
    {
      'name': 'Macchiato',
      'price': 'R\$ 11,90',
      'icon': Icons.coffee,
      'category': 'Cafés Quentes',
    },
    {
      'name': 'Cold Brew Caffeto',
      'price': 'R\$ 13,50',
      'icon': Icons.local_drink,
      'category': 'Cafés Gelados',
    },
    {
      'name': 'Frappuccino Caramelo',
      'price': 'R\$ 16,90',
      'icon': Icons.local_drink,
      'category': 'Cafés Gelados',
    },
    {
      'name': 'Cappuccino Gelado',
      'price': 'R\$ 15,90',
      'icon': Icons.local_drink,
      'category': 'Cafés Gelados',
    },
    {
      'name': 'Latte Gelado',
      'price': 'R\$ 14,90',
      'icon': Icons.local_drink,
      'category': 'Cafés Gelados',
    },
    {
      'name': 'Combo Pão de Mel + Café',
      'price': 'R\$ 19,90',
      'icon': Icons.cake,
      'category': 'Combos',
    },
    {
      'name': 'Combo Croissant + Café',
      'price': 'R\$ 17,90',
      'icon': Icons.bakery_dining,
      'category': 'Combos',
    },
    {
      'name': 'Combo Bolo + Café',
      'price': 'R\$ 21,90',
      'icon': Icons.cake,
      'category': 'Combos',
    },
  ];

  List<Map<String, dynamic>> get filteredItems {
    return allItems.where((item) {
      final matchSearch =
          _searchQuery.isEmpty ||
          item['name'].toString().toLowerCase().contains(
            _searchQuery.toLowerCase(),
          );
      final matchCategory =
          _selectedCategory == null || item['category'] == _selectedCategory;
      return matchSearch && matchCategory;
    }).toList();
  }

  void _addToCart(Map<String, dynamic> item) {
    setState(() => CartController.instance.addItem(item));
    widget.onCartChanged?.call();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${item['name']} adicionado à sacola!'),
        backgroundColor: const Color(0xFFC8A96E),
        duration: const Duration(seconds: 1),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Cardápio',
          style: TextStyle(
            color: Color(0xFF1A1A1A),
            fontWeight: FontWeight.w800,
            fontSize: 20,
          ),
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // CATEGORIAS NO TOPO (ícone + label)
          SizedBox(
            height: 100,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: categoryList.length,
              itemBuilder: (context, index) {
                final cat = categoryList[index];
                final isSelected = _selectedCategory == cat['label'];
                return GestureDetector(
                  onTap: () => setState(
                    () => _selectedCategory = isSelected
                        ? null
                        : cat['label'] as String,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          width: 60,
                          height: 60,
                          decoration: BoxDecoration(
                            color: isSelected
                                ? const Color(0xFFC8A96E)
                                : const Color(0xFFF5F0E8),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Icon(
                            cat['icon'] as IconData,
                            color: isSelected
                                ? Colors.white
                                : const Color(0xFFC8A96E),
                            size: 28,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          cat['label'],
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: isSelected
                                ? const Color(0xFFC8A96E)
                                : const Color(0xFF1A1A1A),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // BUSCA
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFFF5F0E8),
                borderRadius: BorderRadius.circular(30),
              ),
              child: TextField(
                controller: _searchController,
                onChanged: (val) => setState(() => _searchQuery = val),
                decoration: InputDecoration(
                  hintText: 'Buscar no cardápio...',
                  hintStyle: const TextStyle(
                    color: Color(0xFF9E9E9E),
                    fontSize: 14,
                  ),
                  suffixIcon: _searchQuery.isNotEmpty
                      ? GestureDetector(
                          onTap: () {
                            _searchController.clear();
                            setState(() => _searchQuery = '');
                          },
                          child: const Icon(
                            Icons.close,
                            color: Color(0xFF9E9E9E),
                          ),
                        )
                      : const Icon(Icons.search, color: Color(0xFF9E9E9E)),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 14,
                  ),
                ),
              ),
            ),
          ),

          // LISTA DE PRODUTOS
          Expanded(
            child: filteredItems.isEmpty
                ? const Center(
                    child: Text(
                      'Nenhum produto encontrado',
                      style: TextStyle(color: Color(0xFF9E9E9E), fontSize: 14),
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    itemCount: filteredItems.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final item = filteredItems[index];
                      final qty = CartController.instance.qtyOf(item['name']);
                      return Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF5F0E8),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 60,
                              height: 60,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Icon(
                                item['icon'] as IconData,
                                color: const Color(0xFFC8A96E),
                                size: 32,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item['name'],
                                    style: const TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                      color: Color(0xFF1A1A1A),
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    item['category'],
                                    style: const TextStyle(
                                      fontSize: 12,
                                      color: Color(0xFF9E9E9E),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  item['price'],
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800,
                                    color: Color(0xFFC8A96E),
                                  ),
                                ),
                                const SizedBox(height: 6),
                                GestureDetector(
                                  onTap: () => _addToCart(item),
                                  child: Container(
                                    width: 32,
                                    height: 32,
                                    decoration: const BoxDecoration(
                                      color: Color(0xFFC8A96E),
                                      shape: BoxShape.circle,
                                    ),
                                    child: Center(
                                      child: qty > 0
                                          ? Text(
                                              '$qty',
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 12,
                                                fontWeight: FontWeight.w800,
                                              ),
                                            )
                                          : const Icon(
                                              Icons.add,
                                              color: Colors.white,
                                              size: 18,
                                            ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
