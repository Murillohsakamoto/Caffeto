import 'package:flutter/material.dart';
import 'dart:async';
import 'login_screen.dart';
import 'cardapio_screen.dart';
import 'sacola_screen.dart';
import 'perfil_screen.dart';
import 'cart_controller.dart';

void main() {
  runApp(const CaffetoApp());
}

class CaffetoApp extends StatelessWidget {
  const CaffetoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Caffeto',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFC8A96E)),
        useMaterial3: true,
      ),
      home: const LoginScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  void _refresh() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final pages = [
      _HomePage(onCartChanged: _refresh),
      CardapioScreen(onCartChanged: _refresh),
      SacolaScreen(),
      const PerfilScreen(),
    ];

    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: _buildBottomNavBar(),
    );
  }

  Widget _buildBottomNavBar() {
    final items = [
      {'icon': Icons.home, 'label': 'Início'},
      {'icon': Icons.restaurant_menu, 'label': 'Cardápio'},
      {'icon': Icons.shopping_bag_outlined, 'label': 'Sacola'},
      {'icon': Icons.person_outline, 'label': 'Perfil'},
    ];

    return Container(
      height: 60,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Color(0xFFEEEEEE))),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(items.length, (index) {
          final isActive = index == _selectedIndex;
          final isSacola = index == 2;
          final cartCount = CartController.instance.totalItems;

          return GestureDetector(
            onTap: () => setState(() => _selectedIndex = index),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      items[index]['icon'] as IconData,
                      color: isActive
                          ? const Color(0xFFC8A96E)
                          : const Color(0xFF9E9E9E),
                      size: 22,
                    ),
                    Text(
                      items[index]['label'] as String,
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: isActive
                            ? FontWeight.w700
                            : FontWeight.w400,
                        color: isActive
                            ? const Color(0xFFC8A96E)
                            : const Color(0xFF9E9E9E),
                      ),
                    ),
                  ],
                ),
                if (isSacola && cartCount > 0)
                  Positioned(
                    top: 4,
                    right: -6,
                    child: Container(
                      width: 16,
                      height: 16,
                      decoration: const BoxDecoration(
                        color: Color(0xFFC8A96E),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          '$cartCount',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

// ────────────────────────────────────────────
//  HOME PAGE
// ────────────────────────────────────────────

class _HomePage extends StatefulWidget {
  final VoidCallback onCartChanged;
  const _HomePage({required this.onCartChanged});

  @override
  State<_HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<_HomePage> {
  final PageController _pageController = PageController(viewportFraction: 0.85);
  final TextEditingController _searchController = TextEditingController();
  Timer? _autoScrollTimer;

  int _currentPage = 0;
  String _searchQuery = '';

  final List<Map<String, dynamic>> allProducts = const [
    {'name': 'Cappuccino Clássico', 'price': 'R\$ 12,90', 'icon': Icons.coffee},
    {
      'name': 'Latte de Baunilha',
      'price': 'R\$ 14,90',
      'icon': Icons.local_cafe,
    },
    {'name': 'Espresso Duplo', 'price': 'R\$ 9,90', 'icon': Icons.coffee_maker},
    {
      'name': 'Cold Brew Caffeto',
      'price': 'R\$ 13,50',
      'icon': Icons.local_drink,
    },
    {
      'name': 'Frappuccino Caramelo',
      'price': 'R\$ 16,90',
      'icon': Icons.local_drink,
    },
    {
      'name': 'Combo Pão de Mel + Café',
      'price': 'R\$ 19,90',
      'icon': Icons.cake,
    },
    {
      'name': 'Combo Croissant + Café',
      'price': 'R\$ 17,90',
      'icon': Icons.bakery_dining,
    },
  ];

  final List<Map<String, dynamic>> partners = [
    {
      'name': 'Grão & Cia',
      'subtitle': 'Torrefação Especial',
      'color': const Color(0xFF6B3F1E),
    },
    {
      'name': 'Doce Aroma',
      'subtitle': 'Confeitaria Artesanal',
      'color': const Color(0xFFC8A96E),
    },
    {
      'name': 'Pão & Afeto',
      'subtitle': 'Padaria Premium',
      'color': const Color(0xFF8B5E3C),
    },
    {
      'name': 'Leite & Arte',
      'subtitle': 'Laticínios Selecionados',
      'color': const Color(0xFFD4A96A),
    },
    {
      'name': 'Verde Vivo',
      'subtitle': 'Orgânicos & Naturais',
      'color': const Color(0xFF5C8A4A),
    },
  ];

  List<Map<String, dynamic>> get filteredProducts {
    if (_searchQuery.isEmpty) return allProducts;
    return allProducts
        .where(
          (p) => p['name'].toString().toLowerCase().contains(
            _searchQuery.toLowerCase(),
          ),
        )
        .toList();
  }

  @override
  void initState() {
    super.initState();
    _startAutoScroll();
  }

  void _startAutoScroll() {
    _autoScrollTimer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (!mounted) return;
      final next = (_currentPage + 1) % partners.length;
      _pageController.animateToPage(
        next,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  void dispose() {
    _autoScrollTimer?.cancel();
    _pageController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _addToCart(Map<String, dynamic> product) {
    setState(() => CartController.instance.addItem(product));
    widget.onCartChanged();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${product['name']} adicionado à sacola!'),
        backgroundColor: const Color(0xFFC8A96E),
        duration: const Duration(seconds: 1),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            _buildSearchBar(),
            _buildPartnersSection(), // 1. Parceiros rotativos
            _buildProductsSection(), // 2. Destaques abaixo
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Image.asset('assets/logo.png', height: 40),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'RETIRAR EM',
                  style: TextStyle(
                    fontSize: 11,
                    color: Color(0xFF9E9E9E),
                    fontWeight: FontWeight.w400,
                  ),
                ),
                Text(
                  'Unidade Ibirapuera',
                  style: TextStyle(
                    fontSize: 15,
                    color: Color(0xFF1A1A1A),
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          const Icon(
            Icons.keyboard_arrow_down,
            color: Color(0xFFC8A96E),
            size: 24,
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFFF5F0E8),
          borderRadius: BorderRadius.circular(30),
        ),
        child: TextField(
          controller: _searchController,
          onChanged: (val) => setState(() => _searchQuery = val),
          decoration: InputDecoration(
            hintText: 'O que deseja pedir?',
            hintStyle: const TextStyle(color: Color(0xFF9E9E9E), fontSize: 14),
            suffixIcon: _searchQuery.isNotEmpty
                ? GestureDetector(
                    onTap: () {
                      _searchController.clear();
                      setState(() => _searchQuery = '');
                    },
                    child: const Icon(Icons.close, color: Color(0xFF9E9E9E)),
                  )
                : const Icon(Icons.search, color: Color(0xFF9E9E9E)),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 20,
              vertical: 14,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPartnersSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 16, top: 12, bottom: 12),
          child: Text(
            'NOSSOS PARCEIROS',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w800,
              color: Color(0xFF1A1A1A),
            ),
          ),
        ),
        SizedBox(
          height: 130,
          child: PageView.builder(
            controller: _pageController,
            itemCount: partners.length,
            onPageChanged: (i) => setState(() => _currentPage = i),
            itemBuilder: (context, index) {
              final partner = partners[index];
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Container(
                  decoration: BoxDecoration(
                    color: partner['color'] as Color,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.storefront,
                          color: Colors.white,
                          size: 28,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              partner['name'],
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              partner['subtitle'],
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.85),
                                fontSize: 12,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: const Text(
                                'Ver mais',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(partners.length, (index) {
            final isActive = index == _currentPage;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: isActive ? 16 : 5,
              height: 5,
              decoration: BoxDecoration(
                color: isActive
                    ? const Color(0xFFC8A96E)
                    : const Color(0xFFD9D9D9),
                borderRadius: BorderRadius.circular(4),
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildProductsSection() {
    final products = filteredProducts;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 16, top: 20, bottom: 8),
          child: Row(
            children: [
              const Text(
                'EM DESTAQUE',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF1A1A1A),
                ),
              ),
              if (_searchQuery.isNotEmpty)
                GestureDetector(
                  onTap: () => setState(() {
                    _searchQuery = '';
                    _searchController.clear();
                  }),
                  child: const Padding(
                    padding: EdgeInsets.only(left: 8),
                    child: Icon(
                      Icons.close,
                      size: 16,
                      color: Color(0xFFC8A96E),
                    ),
                  ),
                ),
            ],
          ),
        ),
        if (products.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 24),
            child: Center(
              child: Text(
                'Nenhum produto encontrado',
                style: TextStyle(color: Color(0xFF9E9E9E), fontSize: 14),
              ),
            ),
          )
        else
          SizedBox(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: products.length,
              itemBuilder: (context, index) {
                final product = products[index];
                final qty = CartController.instance.qtyOf(product['name']);
                return Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: Container(
                    width: 150,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF5F0E8),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Center(
                          child: Icon(
                            product['icon'] as IconData,
                            color: const Color(0xFFC8A96E),
                            size: 70,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          product['name'],
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF1A1A1A),
                          ),
                        ),
                        const Spacer(),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              product['price'],
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFFC8A96E),
                              ),
                            ),
                            GestureDetector(
                              onTap: () => _addToCart(product),
                              child: Container(
                                width: 28,
                                height: 28,
                                decoration: const BoxDecoration(
                                  color: Color(0xFFC8A96E),
                                  shape: BoxShape.circle,
                                ),
                                child: Center(
                                  child: qty > 0
                                      ? Text(
                                          '$qty',
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 11,
                                            fontWeight: FontWeight.w800,
                                          ),
                                        )
                                      : const Icon(
                                          Icons.add,
                                          color: Colors.white,
                                          size: 18,
                                        ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
      ],
    );
  }
}
